ALTER TABLE rooms
	ADD ward_id uuid;

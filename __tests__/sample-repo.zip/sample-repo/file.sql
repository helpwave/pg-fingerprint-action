-- comment
ALTER TABLE rooms -- comment
	ADD ward_id uuid NOT NULL; --comment
-- comment
